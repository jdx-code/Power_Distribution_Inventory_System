<?php
session_start();
unset($_SESSION["uid"]);
unset($_SESSION["fullname"]);
header("Location:index.php");
 ?>
