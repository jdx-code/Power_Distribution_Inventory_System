<?php
  require_once 'connect.php';
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Add Items</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/checkout/">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/form-validation.css" rel="stylesheet">
  </head>

  <body class="bg-light">

    <div class="container">
      <div class="py-5 text-center">
        <img class="d-block mx-auto mb-4" src="https://getbootstrap.com/docs/4.0/assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
        <h2>Checkout form</h2>
        <p class="lead">Below is an example form built entirely with Bootstrap's form controls. Each required form group has a validation state that can be triggered by attempting to submit the form without completing it.</p>
      </div>

      <div class="row">
        <div class="col-md-4 order-md-2 mb-4">
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Your cart</span>
            <span class="badge badge-secondary badge-pill">3</span>
          </h4>
          <ul class="list-group mb-3">
            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h6 class="my-0">Product name</h6>
                <small class="text-muted">Brief description</small>
              </div>
              <span class="text-muted">$12</span>
            </li>
            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h6 class="my-0">Second product</h6>
                <small class="text-muted">Brief description</small>
              </div>
              <span class="text-muted">$8</span>
            </li>
            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h6 class="my-0">Third item</h6>
                <small class="text-muted">Brief description</small>
              </div>
              <span class="text-muted">$5</span>
            </li>
            <li class="list-group-item d-flex justify-content-between bg-light">
              <div class="text-success">
                <h6 class="my-0">Promo code</h6>
                <small>EXAMPLECODE</small>
              </div>
              <span class="text-success">-$5</span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
              <span>Total (USD)</span>
              <strong>$20</strong>
            </li>
          </ul>

        </div>
        <div class="col-md-8 order-md-1">
          <h4 class="mb-3">Billing address</h4>
          <form class="needs-validation" action="add_items2.php" method="post" novalidate>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="firstName">Item name</label>
                <input type="text" class="form-control" id="firstName" name="item_name" placeholder="" value="" required>
                <div class="invalid-feedback">
                  Valid item name is required.
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Select Category</label>
                <select class="form-control" name="category" required>
                  <option></option>
                  <?php
                    $sql   = "SELECT * FROM category";
                    $result = mysqli_query($conn,$sql);
                    while($row = mysqli_fetch_array($result)){
                      echo '<option value='.$row['cat_id'].'>'.$row['cat_name'].'</option>';
                    }
                  ?>
                </select>
                <div class="invalid-feedback">
                  Valid category is required.
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="firstName">Quantity</label>
                <input type="text" class="form-control" id="firstName" name="quantity" placeholder="" value="" required>
                <div class="invalid-feedback">
                  Valid quantity is required.
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Purchased date</label>
                <input type="text" class="form-control" id="lastName" name="purchased_date" placeholder="" value="" required>
                <div class="invalid-feedback">
                  Valid date is required.
                </div>
              </div>
            </div>

            <div class="mb-3">
              <label for="address">Purchased from</label>
              <input type="text" class="form-control" id="address" name="purchased_from" placeholder="" required>
              <div class="invalid-feedback">
                Please enter the Purchased from.
              </div>
            </div>

            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="firstName">Price per unit</label>
                <input type="text" class="form-control" id="firstName" name="price_per_unit" placeholder="" value="" required>
                <div class="invalid-feedback">
                  Valid quantity is required.
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Total Price</label>
                <input type="text" class="form-control" id="lastName" name="total_price" placeholder="" value="" required>
                <div class="invalid-feedback">
                  Valid date is required.
                </div>
              </div>
            </div>

            <div class="mb-3">
              <label for="address">Total Price in Words (Rupees)</label>
              <input type="text" class="form-control" id="address" name="price_in_words" placeholder="" required>
              <div class="invalid-feedback">
                Please enter the Purchased from.
              </div>
            </div>


            <hr class="mb-4">
            <button class="btn btn-primary btn-lg btn-block" type="submit">Submit Information</button>
          </form>
        </div>
      </div>

      <footer class="my-5 pt-5 text-muted text-center text-small">
        <p class="mb-1">&copy; 2017-2018 Company Name</p>
        <ul class="list-inline">
          <li class="list-inline-item"><a href="#">Privacy</a></li>
          <li class="list-inline-item"><a href="#">Terms</a></li>
          <li class="list-inline-item"><a href="#">Support</a></li>
        </ul>
      </footer>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-3.3.1.slim.min" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-3.3.1.slim.min.js"><\/script>')</script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/holder.min.js"></script>
    <script>
      // Example starter JavaScript for disabling form submissions if there are invalid fields
      (function() {
        'use strict';

        window.addEventListener('load', function() {
          // Fetch all the forms we want to apply custom Bootstrap validation styles to
          var forms = document.getElementsByClassName('needs-validation');

          // Loop over them and prevent submission
          var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
              if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
              }
              form.classList.add('was-validated');
            }, false);
          });
        }, false);
      })();
    </script>
  </body>
</html>
