<?php
  require_once 'connect.php';

  $user_id          = $_POST['user_id'];
  $designation      = $_POST['designation'];
  $doj              = $_POST['doj'];

  $sql   = "INSERT INTO employee (emp_id,doj,emp_designation,user_id) VALUES (DEFAULT,'$doj','$designation','$user_id')";
  $query = mysqli_query($conn,$sql);
?>
