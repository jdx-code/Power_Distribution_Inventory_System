<?php
require_once 'connect.php';

$sl_no = $_GET['sl_no'];
$sql     = "DELETE FROM item_status where sl_no = '$sl_no'";
$query   = mysqli_query($conn,$sql);
header('Location: item_status.php');
?>
