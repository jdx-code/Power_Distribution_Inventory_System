<?php
require_once 'connect.php';

$username = $_POST['username'];
$password = $_POST['password'];
$fullname = $_POST['fullname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$gender = $_POST['gender'];
$dob = $_POST['dob'];
$country = $_POST['country'];
$city = $_POST['city'];

$sql = "INSERT INTO users (user_id,user_name,password,full_name,email_id,phone_no,country,city,dob,gender,reg_datetime,status) VALUES (DEFAULT,'$username','$password','$fullname','$email','$phone','$country','$city','$dob','$gender',NOW(),0)";
$query = mysqli_query($conn,$sql)
?>
