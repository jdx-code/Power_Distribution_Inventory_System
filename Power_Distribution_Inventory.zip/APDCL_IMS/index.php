
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Jumbotron Template for Bootstrap</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/jumbotron/">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/jumbotron.css" rel="stylesheet">
  </head>

  <body>

    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <a class="navbar-brand" href="#">Home</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenterLogin">
              Admin Login
        </button>

          </li>
          <li class="nav-item">
            <a class="nav-link" href="registration1.php">Registration</a>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled" href="#">Disabled</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="http://example.com" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <a class="dropdown-item" href="#">Something else here</a>
            </div>
          </li>
        </ul>
        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
          &nbsp;&nbsp;
        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenterEmployee">
                  Employee Login
          </button>
        </form>
      </div>
    </nav>

    <main role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class="jumbotron">
        <div class="container-fluid">
          <img src="img/apdcl.png" height="300" width="1400">
          <p><a class="btn btn-primary btn-lg" href="https://www.apdcl.org" role="button">Learn more &raquo;</a></p>
        </div>
      </div>

      <div class="container">
        <!-- Example row of columns -->
        <div class="row">
          <div class="col-md-4">
            <h2>About us</h2>
            The Company, Assam Power Distribution Company Ltd. was incorporated on the 23rd day of October, 2009 as a public limited company wholly owned by the Government of Assam. The ultimate object of the Company is to undertake the electricity distribution, trading, supply in the state of Assam or outside in accordance with provisions of Applicable Law and all activities ancillary or appurtenant thereto.

The main purpose of forming the Company was to take over, manage and operate the electricity distribution system, assets, liabilities, undertaking of the Assam State Electricity Board (ASEB), as may be transferred to it pursuant to a notified transfer scheme in terms of Part XIII of the Electricity Act, 2003. Subsequently, the Government of Assam notified the provisional transfer scheme vide Gazette notification bearing no. PEL. 151/2003/Pt./165 dated 10th December, 2004 as well as the final transfer scheme vide Gazette Notification PEL.151/2003/Pt./349 dated Dispur, the 16th August, 2005 under the Electricity Act, 2003 transferring the various assets, liabilities etc. of the ASEB to the Company.

The main object of the company is to develop, maintain and operate power distribution system in the state of Assam
            </div>
            <div class="col-md-4">
              <img src="img/tower.jpg" height="500" width="800">
            </div>
      <hr>

      </div> <!-- /container -->

      <!-- Modal -->
      <div class="modal fade" id="exampleModalCenterEmployee" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <!-- Employee Login Modal-->
            <div class="modal-body">
              <form class="form-signin" name="Loginform" action="employee_login_check.php" method="post">
                <div class="py-5 text-center">
                <img class="mb-4" src="img/Logo2.png" alt="" width="100" height="100">
                <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
                <label for="inputEmail" class="sr-only">Username</label>
                <input type="text" id="inputUsername" name="username" class="form-control" placeholder="Username" required autofocus>
                <label for="inputPassword" class="sr-only">Password</label>
                <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
                <div class="checkbox mb-3">
                  <label>
                    <input type="checkbox" value="remember-me"> Remember me
                  </label>
                </div>
                <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
              </form>
            </div>
          </div>
        </div>
      </div>

    </main>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-3.2.1.slim.min.js"><\/script>')</script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenterLogin" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <!-- Admin Login Modal-->
          <div class="modal-body">
            <form class="form-signin" name="Loginform" action="Login_Check.php" method="post">
              <div class="py-5 text-center">
              <img class="mb-4" src="img/Logo2.png" alt="" width="100" height="100">
              <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
              <label for="inputEmail" class="sr-only">Username</label>
              <input type="text" id="inputUsername" name="username" class="form-control" placeholder="Username" required autofocus>
              <label for="inputPassword" class="sr-only">Password</label>
              <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
              <div class="checkbox mb-3">
                <label>
                  <input type="checkbox" value="remember-me"> Remember me
                </label>
              </div>
              <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>


  </body>
</html>
