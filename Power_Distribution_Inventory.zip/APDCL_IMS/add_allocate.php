<?php
  require_once 'connect.php';

  $employee         = $_POST['employee'];
  $item             = $_POST['item'];
  $quantity         = $_POST['quantity'];
  $date_taken       = $_POST['date_taken'];

  $sql   = "INSERT INTO item_status (sl_no,item_id,qty_taken,emp_id,date_taken) VALUES (DEFAULT,'$item','$quantity','$employee','$date_taken')";
  $query = mysqli_query($conn,$sql);
?>
