<?php
session_start();
require_once 'connect.php';
$uname = $_POST['username'];
$pass  = $_POST['password'];
$sql   = "SELECT * FROM users WHERE user_name = '$uname' AND password = '$pass' AND status = 1";
$result = mysqli_query($conn,$sql);
$count  = mysqli_num_rows($result);
$row    = mysqli_fetch_array($result);
if($count==1){
  $_SESSION["uid"] = $row[user_id];
  $_SESSION["fullname"] = $row[full_name];
  header("location: admin_dashboard.php");
}
else{
  $error = "Your username and password is incorrect";
  echo $error;
}

?>
