<?php
  require_once 'connect.php';
  $item_id = $_GET['item_id'];
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Add Items</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/checkout/">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/form-validation.css" rel="stylesheet">
  </head>

  <body class="bg-light">

    <div class="container">
      <div class="py-5 text-center">
        <img class="d-block mx-auto mb-4" src="https://getbootstrap.com/docs/4.0/assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
        <h2>Checkout form</h2>
        <p class="lead">Below is an example form built entirely with Bootstrap's form controls. Each required form group has a validation state that can be triggered by attempting to submit the form without completing it.</p>
      </div>


        <?php
          $sql   = "SELECT * FROM item, category WHERE item.item_category = category.cat_id AND item.item_id='$item_id'";
          $result = mysqli_query($conn,$sql);
          while($row = mysqli_fetch_array($result)){

        ?>
        <div class="col-md-6 mb-3">

          <label for="firstName">Item Name</label>
          <input type="text" class="form-control" id="firstName" name="item_name" placeholder="" value="<?php echo $row['item_name'];?>" disabled>
          <div class="invalid-feedback">
            Valid item name is required.
          </div>
        </div>
        <div class="col-md-6 mb-3">
          <label for="firstName">Category</label>
          <input type="text" class="form-control" id="firstName" name="cat_name" placeholder="" value="<?php echo $row['cat_name'];?>" disabled>
          <div class="invalid-feedback">
            Valid Category is required.
          </div>
        </div>
        <div class="col-md-6 mb-3">
          <label for="firstName">Quantity</label>
          <input type="text" class="form-control" id="firstName" name="item_quantity" placeholder="" value="<?php echo $row['item_quantity'];?>" disabled>
          <div class="invalid-feedback">
            Valid Quantity is required.
          </div>
        </div>

        <form class="needs-validation" action="activity_list2.php" method="post" novalidate>


          <input type="hidden" class="form-control" id="firstName" name="item_id" placeholder="" value="<?php echo $row['item_id'];?>">
            <div class="col-md-6 mb-3">
              <label for="firstName">Working</label>
              <input type="text" class="form-control" id="firstName" name="working_status" placeholder="" value="" required>
              <div class="invalid-feedback">
                Valid Status is required.
              </div>
            </div>
            <div class="col-md-6 mb-3">
              <label for="firstName">Not Working</label>
              <input type="text" class="form-control" id="firstName" name="not_working_status" placeholder="" value="" required>
              <div class="invalid-feedback">
                Valid Status is required.
              </div>
            </div>
            <?php
              }
             ?>

            <hr class="mb-4">
            <button class="btn btn-primary btn-lg btn-block" type="submit">Submit Information</button>
          </form>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-3.3.1.slim.min" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-3.3.1.slim.min.js"><\/script>')</script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/holder.min.js"></script>
    <script>
      // Example starter JavaScript for disabling form submissions if there are invalid fields
      (function() {
        'use strict';

        window.addEventListener('load', function() {
          // Fetch all the forms we want to apply custom Bootstrap validation styles to
          var forms = document.getElementsByClassName('needs-validation');

          // Loop over them and prevent submission
          var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
              if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
              }
              form.classList.add('was-validated');
            }, false);
          });
        }, false);
      })();
    </script>
  </body>
</html>
