<?php
require_once 'connect.php';

$emp_id = $_GET['emp_id'];
$sql     = "DELETE FROM employee where emp_id = '$emp_id'";
$query   = mysqli_query($conn,$sql);
header('Location: remove_employee.php');
 ?>
