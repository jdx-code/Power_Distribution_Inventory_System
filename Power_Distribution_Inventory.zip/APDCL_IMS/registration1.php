<?php
require_once 'connect.php';
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/selectbox.css">
<link rel="stylesheet" href="css/radio_button.css">
<style>
body {background-image: url(img/backgrounds.jpg);}
 {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}


.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}

.icon {
  padding: 10px;
  background: red;
  color: white;
  min-width: 50px;
  text-align: center;
}

.input-field {
  width: 100%;
  padding: 10px;
  outline: none;
}

.input-field:focus {
  border: 2px solid dodgerblue;
}

/* Set a style for the submit button */
.btn {
  background-color: red;
  color: white;
  padding: 15px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}
</style>
</head>
<body>

<form name="Registration Form" action="registration2.php" method="post" style="max-width:500px;margin:auto">
     <h1>Registration Form</h1>
     <img src="img/apdclback.jpg" alt="" width="500" height="200">
  <div class="input-container">
    <i class="fa fa-user icon"></i>
    <input class="input-field" type="text" placeholder="Username" name="username">
  </div>

  <div class="input-container">
    <i class="fa fa-key icon"></i>
    <input class="input-field" type="password" placeholder="Password" name="password">
  </div>
  <div class="input-container">
    <i class="fa fa-key icon"></i>
    <input class="input-field" type="password" placeholder="Confirm Password" name="password">
  </div>
  <div class="input-container">
    <i class="fa fa-user icon"></i>
    <input class="input-field" type="text" placeholder="Full Name" name="fullname">
  </div>

  <div class="input-container">
    <i class="fa fa-envelope icon"></i>
    <input class="input-field" type="text" placeholder="Email" name="email">
  </div>

  <div class="input-container">
    <i class="fa fa-phone icon"></i>
    <input class="input-field" type="text" placeholder="Phone No" name="phone">
  </div>

  <div class="input-container">
    <i class="fa fa-male icon" style="height:60px;"> Gender</i>
    <label class="container">Male
      <input type="radio" checked="checked" name="gender" value="male">
      <span class="checkmark"></span>
    </label>
    <label class="container">Female
      <input type="radio" name="gender" value="female">
      <span class="checkmark"></span>
    </label>
  </div>

  <p>
  <div class="input-container">
    <i class="fa fa-calendar-o icon" style="height:50px;"> DOB</i>
    <input class="input-field" type="date" placeholder="DOB" name="dob">
  </div>


  <div class="input-container">
    <div class="col-75">
      <select id="state" name="country">
        <option> Select Country </option>
      <?php
      $sql = "SELECT * FROM countries";
      $result = mysqli_query($conn,$sql);
      while ($row = mysqli_fetch_array($result)) {
        echo '<option>'.$row['country_name'].'</option>';
      }
      ?>
      </select>
    </div>
  </div>
  <div class="input-container">
    <div class="col-75">
      <select id="city" name="city">
        <option> Select City </option>
        <?php
        $sql = "SELECT * FROM cites";
        $result = mysqli_query($conn,$sql);
        while ($row = mysqli_fetch_array($result)) {
          echo '<option>'.$row['city_name'].'</option>';
        }
        ?>
      </select>
    </div>
</div>


  <button type="submit" class="btn">Register</button>
</form>
<script src="js/selectbox.js"></script>
</body>
</html>
