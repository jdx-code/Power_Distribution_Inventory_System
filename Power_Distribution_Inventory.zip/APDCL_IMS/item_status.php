<?php
  require_once 'connect.php';
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Pricing example for Bootstrap</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/pricing/">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/pricing.css" rel="stylesheet">
  </head>

  <body>

    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
      <h5 class="my-0 mr-md-auto font-weight-normal">Company name</h5>
      <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="#">Features</a>
        <a class="p-2 text-dark" href="#">Enterprise</a>
        <a class="p-2 text-dark" href="#">Support</a>
        <a class="p-2 text-dark" href="#">Pricing</a>
      </nav>
      <a class="btn btn-outline-primary" href="#">Sign up</a>
    </div>

    <!--<a type="button" class="btn btn-danger" href="del_item_status.php">CLICK HERE TO ALLOCATE ITEMS</a>-->
    <a type="button" class="btn btn-warning" href="allocate.php">
      <span class="spinner-grow spinner-grow-sm"></span>
      CLICK HERE TO ALLOCATE ITEMS
    </a>
    <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">Employee ID</th>
        <th scope="col">Employee Name</th>
        <th scope="col">Item Held</th>
        <th scope="col">Quantity</th>
        <th scope="col">Phone No</th>
      </tr>
    </thead>

    <?php
      $sql   = "SELECT * FROM users,employee,item,item_status
                WHERE users.user_id = employee.user_id
                AND item.item_id = item_status.item_id
                AND users.user_id = item_status.emp_id";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){

    ?>
    <tbody>
      <tr>
        <td>
          <?php
            echo $row['user_id'];
          ?>
        </td>
        <td>
          <?php
            echo $row['full_name'];
          ?>
        </td>
        <td>
          <?php
            echo $row['item_name'];
          ?>
        </td>
        <td>
          <?php
            echo $row['qty_taken'];
          ?>
        </td>
        <td>
          <?php
            echo $row['phone_no'];
          }
          ?>
        </td>
      </tr>
    </tbody>
  </table>
</div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <script>
      Holder.addTheme('thumb', {
        bg: '#55595c',
        fg: '#eceeef',
        text: 'Thumbnail'
      });
    </script>
  </body>
</html>
