<?php
  require_once 'connect.php';

  $item_id                    = $_POST['item_id'];
  $working_status             = $_POST['working_status'];
  $not_working_status         = $_POST['not_working_status'];

  $sql   =  "UPDATE item SET working_status = '$working_status',
             not_working_status  = '$not_working_status'
             WHERE item_id = '$item_id'";
  $query = mysqli_query($conn,$sql);
  header('Location: item_activity.php');
?>
