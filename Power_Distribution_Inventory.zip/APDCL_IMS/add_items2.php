<?php
  require_once 'connect.php';

  $item_name        = $_POST['item_name'];
  $category         = $_POST['category'];
  $quantity         = $_POST['quantity'];
  $purchased_date   = $_POST['purchased_date'];
  $purchased_from   = $_POST['purchased_from'];
  $price_per_unit   = $_POST['price_per_unit'];
  $total_price      = $_POST['total_price'];
  $price_in_words   = $_POST['price_in_words'];

  $sql   = "INSERT INTO item (item_id,item_name,item_category,item_quantity,purchased_date,purchased_from,price_per_unit,total_price,total_price_in_words) VALUES (DEFAULT,'$item_name','$category','$quantity','$purchased_date','$purchased_from','$price_per_unit','$total_price','$price_in_words')";
  $query = mysqli_query($conn,$sql);
?>
