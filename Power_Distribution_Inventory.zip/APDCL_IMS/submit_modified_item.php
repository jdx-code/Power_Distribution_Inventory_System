<?php
  require_once 'connect.php';

  $item_id          = $_POST['item_id'];
  $item_name        = $_POST['item_name'];
  $item_quantity         = $_POST['item_quantity'];
  $purchased_date   = $_POST['purchased_date'];
  $purchased_from   = $_POST['purchased_from'];
  $price_per_unit   = $_POST['price_per_unit'];
  $total_price      = $_POST['total_price'];
  $price_in_words   = $_POST['price_in_words'];

  $sql   =  "UPDATE item SET item_name = '$item_name',
             item_quantity  = '$item_quantity',
             purchased_date = '$purchased_date',
             purchased_from = '$purchased_from',
             price_per_unit = '$price_per_unit',
             total_price    = '$total_price',
             total_price_in_words = '$price_in_words'
             WHERE item_id = '$item_id'";
  $query = mysqli_query($conn,$sql);
  header('Location: modify_items.php');
?>
