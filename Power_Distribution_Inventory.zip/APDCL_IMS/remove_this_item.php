<?php
require_once 'connect.php';

$item_id = $_GET['item_id'];
$sql     = "DELETE FROM item where item_id = '$item_id'";
$query   = mysqli_query($conn,$sql);
header('Location: remove_items.php');
 ?>
